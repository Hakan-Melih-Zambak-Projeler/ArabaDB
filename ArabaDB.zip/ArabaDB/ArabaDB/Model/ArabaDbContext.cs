﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArabaDB.Model
{
    internal class ArabaDbContext : DbContext
    {
        public DbSet<Araba> Arabalar { get; set; }
        public ArabaDbContext()
        {

        }
        public ArabaDbContext(DbContextOptions<ArabaDbContext> options): base (options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-O07KLML\SQLEXPRESS;Database=ArabaDB;Trusted_Connection=True;TrustServerCertificate=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>(x =>
            {
                x.Property(x => x.ArabaId).HasMaxLength(50);
            });
            base.OnModelCreating(modelBuilder);
        }
    }
}
