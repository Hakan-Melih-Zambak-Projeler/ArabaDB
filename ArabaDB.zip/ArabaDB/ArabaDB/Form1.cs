using ArabaDB.Model;

namespace ArabaDB
{
    public partial class Form1 : Form
    {
        readonly ArabaDbContext _db = new ArabaDbContext();
        public Form1()
        {
            InitializeComponent();
            var x = _db.Arabalar.ToList();
            dgwAraba.DataSource = x;
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                Araba araba = new Araba();
                string model = txtModel.Text.Trim();
                string yil = txtYil.Text.Trim();
                string km = txtKm.Text.Trim();
                string renk = txtRenk.Text.Trim();

                araba.Model = model;
                araba.Yil = yil;
                araba.Km = km;
                araba.Renk = renk;
                _db.Arabalar.Add(araba);
                _db.SaveChanges();
                SetDataInGridView();
                ClearData();
                MessageBox.Show("Araba Eklendi!");
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
            }
        }
        public void SetDataInGridView()
        {
            dgwAraba.AutoGenerateColumns = false;
            dgwAraba.DataSource = _db.Arabalar.ToList();
        }
        public void ClearData()
        {
            txtModel.Text= txtKm.Text = txtRenk.Text = txtYil.Text= string.Empty;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int rowIndex = dgwAraba.CurrentCell.RowIndex;
                int arabaId = (int)dgwAraba.Rows[rowIndex].Cells[0].Value;
                Araba araba = _db.Arabalar.Where(x => x.ArabaId == arabaId).SingleOrDefault();
                if (araba != null)
                {
                    araba.Model = txtModel.Text;
                    araba.Renk = txtRenk.Text;
                    araba.Yil = txtYil.Text;
                    araba.Km = txtKm.Text;
                    _db.Arabalar.Update(araba);
                    _db.SaveChanges();
                }
                dgwAraba.Rows[rowIndex].Cells["Model"].Value = txtModel.Text;
                dgwAraba.Rows[rowIndex].Cells["Yil"].Value = txtYil.Text;
                dgwAraba.Rows[rowIndex].Cells["Km"].Value = txtKm.Text;
                dgwAraba.Rows[rowIndex].Cells["Renk"].Value = txtRenk.Text;
                SetDataInGridView();
                ClearData();
                MessageBox.Show("Araba G�ncellendi!");
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
            }
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SetDataInGridView();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                dgwAraba.DataSource = _db.Arabalar.Where(x => x.Model.Contains(txtFind.Text) || x.Renk.Contains(txtFind.Text) || x.Yil.Contains(txtFind.Text) || x.Km.Contains(txtFind.Text)).ToList();
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int rowIndex = dgwAraba.CurrentCell.RowIndex;
            int arabaId = (int)dgwAraba.Rows[rowIndex].Cells[0].Value;
            Araba araba = _db.Arabalar.Where(x => x.ArabaId == arabaId).SingleOrDefault();
            _db.Arabalar.Remove(araba);
            _db.SaveChanges();
            SetDataInGridView();
            ClearData();
            MessageBox.Show("Araba Silindi!");
        }
    }
}