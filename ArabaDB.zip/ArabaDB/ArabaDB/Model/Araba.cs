﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArabaDB.Model
{
    internal class Araba
    {
        public int ArabaId { get; set; }
        public string Model { get; set; }
        public string Yil { get; set; }
        public string Km { get; set; }
        public string Renk { get; set; }
    }
}
